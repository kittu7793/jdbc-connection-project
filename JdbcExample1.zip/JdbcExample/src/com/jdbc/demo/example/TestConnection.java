package com.jdbc.demo.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class TestConnection {

	public static void main(String[] args) {
		try {
		ResourceBundle rs = ResourceBundle.getBundle("dbParameters");
		String driverName = rs.getString("DB_DRIVER");
		String url = rs.getString("DB_URL");
		String userName = rs.getString("DB_USER");
		String password = rs.getString("DB_PASSWORD");

		
			Class.forName(driverName);
			Connection con = DriverManager.getConnection(url, userName, password);
			if (con.isClosed()) {
				System.out.println("Db connection is closed....");
			} else {
				System.out.println("Connection is opened");
				System.out.println("Closing the db connection....");
				con.close();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
